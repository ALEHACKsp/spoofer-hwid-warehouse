# AntiOS Batch Version

WARNING! This project is outdated and not supported anymore. Use https://github.com/vektort13/AntiOS instead

Bat file to change/spoof windows identificators to protect user from local installed software.
# MAYBE YOU NEED TO CHANGE INDIVIDUAL FOR YOUR SYSTEM
***************************************************************
Open antiOS.bat file from Administrator account after windows startup
-
***************************************************************
List of changed identificators:

1. Username
2. Hostname
3. Current windows build
4. Current windows build number
5. Windows build lab 
6. BuildLabEx
7. BuildGuid
8. CryptoMachineGuid
9. DeviceGuid
10. CKCL Guid
11. HardwareProfileGuid
12. WMIGuid
13. EDGE Guid
14. InstallDate
15. ProductID
16. WindowsUpdateClientID
17. STI Connected ID
18. STI Disconnected ID
19. STI Email ID
20. STI Fax ID
21. STI Print ID
22. STI Scan ID
23. STI ProxyEvent
24. IE ProductID
25. IE KBNumber
26. IE Install date
27. VolumeID
28. MACadress
29. HardwareGUID
30. NetworkAdapterGUID (in progress)

********************************************************************
Usage
-
1. Put all files into C:\antiOS


2. Launch VolumeID64 (one time on new system) and agree license


3. open antiOS.bat


Video -
********************************************************************


# Join the project Antidetect, be elusive!
